
// 🔐 Advanced Security Authentication System
class SecureAuth {
    constructor() {
        this.encryptionKey = this.generateKey();
        this.sessionTimeout = 30 * 60 * 1000; // 30 minutes
        this.maxLoginAttempts = 3;
        this.lockoutTime = 15 * 60 * 1000; // 15 minutes
        this.init();
    }

    // Generate encryption key
    generateKey() {
        return CryptoJS.lib.WordArray.random(256/8).toString();
    }

    // Encrypt sensitive data
    encrypt(data) {
        return CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptionKey).toString();
    }

    // Decrypt sensitive data
    decrypt(encryptedData) {
        try {
            const bytes = CryptoJS.AES.decrypt(encryptedData, this.encryptionKey);
            return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
        } catch (e) {
            return null;
        }
    }

    // Check login attempts
    checkLoginAttempts(email) {
        const attempts = localStorage.getItem(`attempts_${email}`);
        const lockout = localStorage.getItem(`lockout_${email}`);
        
        if (lockout && Date.now() < parseInt(lockout)) {
            const remaining = Math.ceil((parseInt(lockout) - Date.now()) / 60000);
            throw new Error(`حساب شما به مدت ${remaining} دقیقه قفل شده است.`);
        }
        
        return attempts ? parseInt(attempts) : 0;
    }

    // Record failed attempt
    recordFailedAttempt(email) {
        const attempts = this.checkLoginAttempts(email) + 1;
        localStorage.setItem(`attempts_${email}`, attempts.toString());
        
        if (attempts >= this.maxLoginAttempts) {
            localStorage.setItem(`lockout_${email}`, (Date.now() + this.lockoutTime).toString());
            throw new Error(`بیش از حد تلاش ناموفق. حساب شما برای 15 دقیقه قفل شد.`);
        }
        
        throw new Error(`رمز عبور اشتباه. ${this.maxLoginAttempts - attempts} تلاش باقی مانده.`);
    }

    // Clear login attempts
    clearLoginAttempts(email) {
        localStorage.removeItem(`attempts_${email}`);
        localStorage.removeItem(`lockout_${email}`);
    }

    // Validate password strength
    validatePassword(password) {
        const requirements = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /\d/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };

        const passed = Object.values(requirements).filter(Boolean).length;
        if (passed < 4) {
            throw new Error('رمز عبور باید حداقل 8 کاراکتر و شامل حروف بزرگ، کوچک، عدد و نماد باشد.');
        }
        
        return true;
    }

    // Session management
    createSession(user) {
        const sessionData = {
            user: user,
            timestamp: Date.now(),
            expires: Date.now() + this.sessionTimeout,
            sessionId: this.generateSessionId()
        };

        const encryptedSession = this.encrypt(sessionData);
        localStorage.setItem('secureSession', encryptedSession);
        
        // Auto logout on timeout
        setTimeout(() => {
            this.logout();
        }, this.sessionTimeout);

        return sessionData;
    }

    // Generate unique session ID
    generateSessionId() {
        return Math.random().toString(36).substring(2) + Date.now().toString(36);
    }

    // Validate session
    validateSession() {
        const encryptedSession = localStorage.getItem('secureSession');
        if (!encryptedSession) return null;

        const session = this.decrypt(encryptedSession);
        if (!session || Date.now() > session.expires) {
            this.logout();
            return null;
        }

        return session;
    }

    // Logout
    logout() {
        localStorage.removeItem('secureSession');
        localStorage.removeItem('currentUser');
        sessionStorage.clear();
        window.location.href = '../login.html';
    }

    // Initialize security measures
    init() {
        // Prevent right-click
        document.addEventListener('contextmenu', e => e.preventDefault());
        
        // Prevent F12, Ctrl+Shift+I, Ctrl+U
        document.addEventListener('keydown', e => {
            if (e.key === 'F12' || 
                (e.ctrlKey && e.shiftKey && e.key === 'I') ||
                (e.ctrlKey && e.key === 'u')) {
                e.preventDefault();
                this.showSecurityAlert();
            }
        });

        // Detect developer tools
        setInterval(() => {
            if (window.devtools && window.devtools.open) {
                this.showSecurityAlert();
            }
        }, 1000);
    }

    // Show security alert
    showSecurityAlert() {
        alert('⚠️ Security Alert: Developer tools are not allowed!');
        this.logout();
    }
}

// Initialize security system
window.secureAuth = new SecureAuth();
console.log('🔐 Security system initialized');
SECURE_AUTH_END