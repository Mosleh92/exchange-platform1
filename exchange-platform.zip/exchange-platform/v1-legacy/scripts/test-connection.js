const mysql = require('mysql2/promise');
require('dotenv').config();

async function testConnection() {
    console.log('🧪 Testing InfinityFree MySQL connection...');
    console.log(`📍 Host: ${process.env.DB_HOST}`);
    console.log(`👤 User: ${process.env.DB_USER}`);
    console.log(`🗄️ Database: ${process.env.DB_NAME}`);

    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            port: process.env.DB_PORT,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME
        });

        await connection.execute('SELECT 1');
        console.log('✅ Connection successful!');

        // Test table creation
        await connection.execute('SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = ?', [process.env.DB_NAME]);
        console.log('✅ Database access confirmed!');

        await connection.end();
        console.log('🎉 InfinityFree MySQL ready for deployment!');

    } catch (error) {
        console.error('❌ Connection failed:', error.message);
        console.log('\n🔧 Check these:');
        console.log('   1. Database credentials in .env');
        console.log('   2. InfinityFree database is created');
        console.log('   3. IP whitelist (if any)');
    }
}

testConnection();