import { Controller, Get, Res } from '@nestjs/common';
import { exec } from 'child_process';
import { Response } from 'express';

@Controller('backup')
export class BackupController {
  @Get()
  exportDb(@Res() res: Response) {
    const dumpPath = './backups/db_dump.sql';
    exec(`pg_dump -U postgres -d exchange > ${dumpPath}`, (err) => {
      if (err) {
        return res.status(500).send('Backup failed');
      }
      res.download(dumpPath);
    });
  }
}