const moment = require('moment-jalaali');
const axios = require('axios');
const logger = require('../utils/logger');
const { formatCurrency } = require('../utils/helpers');

class ExchangeRateController {
  // دریافت نرخ‌های فعلی
  async getCurrentRates(req, res) {
    try {
      const tenantDB = req.tenant.db;
      
      // دریافت نرخ‌های tenant
      let rates = await tenantDB.collection('exchange_rates').findOne({
        type: 'current'
      });

      if (!rates) {
        // اگر نرخی وجود ندارد، نرخ‌های پیش‌فرض ایجاد کن
        rates = await this.initializeDefaultRates(tenantDB);
      }

      // بررسی تازگی نرخ‌ها (اگر بیش از 5 دقیقه قدیمی باشد)
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      if (rates.updated_at < fiveMinutesAgo) {
        // به‌روزرسانی از منابع آنلاین
        try {
          const onlineRates = await this.fetchLiveRates();
          if (onlineRates) {
            rates = await this.updateTenantRates(tenantDB, onlineRates);
          }
        } catch (error) {
          logger.warn('Failed to update rates from online source:', error);
        }
      }

      // محاسبه درصد تغییرات
      const previousRates = await tenantDB.collection('exchange_rates').findOne({
        type: 'previous'
      });

      const changes = this.calculateRateChanges(rates.rates, previousRates?.rates);

      res.json({
        success: true,
        data: {
          rates: rates.rates,
          changes,
          last_updated: rates.updated_at,
          source: rates.source || 'manual',
          is_live: rates.is_live || false,
          formatted_rates: this.formatRatesDisplay(rates.rates)
        }
      });

    } catch (error) {
      logger.error('Get current rates error:', error);
      res.status(500).json({
        error: 'Failed to fetch exchange rates',
        code: 'RATES_FETCH_ERROR'
      });
    }
  }

  // تاریخچه نرخ‌ها
  async getRateHistory(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        currency_pair = 'USD_IRR',
        start_date = moment().subtract(30, 'days').toDate(),
        end_date = new Date(),
        interval = 'daily'
      } = req.query;

      const dateFilter = {
        created_at: {
          $gte: new Date(start_date),
          $lte: new Date(end_date)
        }
      };

      const history = await tenantDB.collection('rate_history').aggregate([
        { $match: { ...dateFilter, currency_pair } },
        {
          $group: {
            _id: this.getIntervalGrouping(interval),
            buy_rate: { $avg: '$buy_rate' },
            sell_rate: { $avg: '$sell_rate' },
            high: { $max: '$buy_rate' },
            low: { $min: '$sell_rate' },
            count: { $sum: 1 },
            date: { $first: '$created_at' }
          }
        },
        { $sort: { '_id': 1 } }
      ]).toArray();

      // محاسبه آمار
      const stats = this.calculateRateStatistics(history);

      res.json({
        success: true,
        data: {
          currency_pair,
          period: { start_date, end_date },
          interval,
          history,
          statistics: stats,
          chart_data: this.formatChartData(history)
        }
      });

    } catch (error) {
      logger.error('Get rate history error:', error);
      res.status(500).json({
        error: 'Failed to fetch rate history',
        code: 'RATE_HISTORY_ERROR'
      });
    }
  }

  // به‌روزرسانی نرخ‌ها
  async updateRates(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { rates, apply_markup = true, source = 'manual' } = req.body;

      // اعتبارسنجی نرخ‌ها
      const validatedRates = this.validateRates(rates);
      if (!validatedRates.isValid) {
        return res.status(400).json({
          error: 'Invalid rates provided',
          details: validatedRates.errors
        });
      }

      // ذخیره نرخ قبلی
      const currentRates = await tenantDB.collection('exchange_rates').findOne({
        type: 'current'
      });

      if (currentRates) {
        await tenantDB.collection('exchange_rates').updateOne(
          { type: 'previous' },
          {
            $set: {
              rates: currentRates.rates,
              updated_at: currentRates.updated_at,
              source: currentRates.source
            }
          },
          { upsert: true }
        );
      }

      // اعمال markup اگر لازم باشد
      let finalRates = rates;
      if (apply_markup) {
        const markupSettings = await this.getMarkupSettings(tenantDB);
        finalRates = this.applyMarkup(rates, markupSettings);
      }

      // به‌روزرسانی نرخ‌های فعلی
      await tenantDB.collection('exchange_rates').updateOne(
        { type: 'current' },
        {
          $set: {
            rates: finalRates,
            updated_at: new Date(),
            updated_by: req.user.userId,
            source,
            is_live: source === 'api'
          }
        },
        { upsert: true }
      );

      // ذخیره در تاریخچه
      await this.saveRateHistory(tenantDB, finalRates, source, req.user.userId);

      // ارسال اطلاع‌رسانی به کلاینت‌ها
      const io = req.app.get('io');
      if (io) {
        io.to(`tenant_${req.tenant.id}`).emit('rates_updated', {
          rates: finalRates,
          updated_at: new Date(),
          source
        });
      }

      // بررسی هشدارهای نرخ
      await this.checkRateAlerts(tenantDB, finalRates);

      logger.info(`Exchange rates updated`, {
        tenantId: req.tenant.id,
        userId: req.user.userId,
        source,
        ratesCount: Object.keys(finalRates).length
      });

      res.json({
        success: true,
        message: 'Exchange rates updated successfully',
        data: {
          rates: finalRates,
          updated_at: new Date(),
          source,
          formatted_rates: this.formatRatesDisplay(finalRates)
        }
      });

    } catch (error) {
      logger.error('Update rates error:', error);
      res.status(500).json({
        error: 'Failed to update exchange rates',
        code: 'RATES_UPDATE_ERROR'
      });
    }
  }

  // ایجاد هشدار نرخ
  async createRateAlert(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        currency_pair,
        threshold,
        type, // 'above' or 'below'
        notification_method = 'email',
        is_active = true
      } = req.body;

      const alert = {
        currency_pair,
        threshold: parseFloat(threshold),
        type,
        notification_method,
        is_active,
        created_by: req.user.userId,
        created_by_name: req.user.name,
        created_at: new Date(),
        triggered_count: 0,
        last_triggered: null
      };

      const result = await tenantDB.collection('rate_alerts').insertOne(alert);

      logger.info(`Rate alert created`, {
        tenantId: req.tenant.id,
        alertId: result.insertedId,
        currency_pair,
        threshold,
        type,
        userId: req.user.userId
      });

      res.status(201).json({
        success: true,
        message: 'Rate alert created successfully',
        data: {
          alert_id: result.insertedId,
          currency_pair,
          threshold,
          type
        }
      });

    } catch (error) {
      logger.error('Create rate alert error:', error);
      res.status(500).json({
        error: 'Failed to create rate alert',
        code: 'RATE_ALERT_ERROR'
      });
    }
  }

  // Helper Methods
  async fetchLiveRates() {
    try {
      // استفاده از API نرخ ارز
      const apiKey = process.env.CURRENCY_API_KEY;
      if (!apiKey) {
        throw new Error('Currency API key not configured');
      }

      const response = await axios.get(`https://api.currencylayer.com/live`, {
        params: {
          access_key: apiKey,
          currencies: 'IRR,USD,EUR,GBP,AED',
          source: 'USD',
          format: 1
        },
        timeout: 10000
      });

      if (response.data.success) {
        return {
          USD_IRR: response.data.quotes.USDIRR || 42000,
          EUR_IRR: response.data.quotes.EURIRR || 45000,
          GBP_IRR: response.data.quotes.GBPIRR || 52000,
          AED_IRR: response.data.quotes.AEDIRR || 11500,
          updated_at: new Date()
        };
      } else {
        throw new Error('API returned error: ' + response.data.error?.info);
      }

    } catch (error) {
      logger.warn('Live rates fetch failed:', error.message);
      
      // Fallback rates
      return {
        USD_IRR: 42000,
        EUR_IRR: 45000,
        GBP_IRR: 52000,
        AED_IRR: 11500,
        updated_at: new Date()
      };
    }
  }

  async initializeDefaultRates(tenantDB) {
    const defaultRates = {
      USD_IRR: { buy: 42000, sell: 42500 },
      EUR_IRR: { buy: 45000, sell: 45600 },
      GBP_IRR: { buy: 52000, sell: 52700 },
      AED_IRR: { buy: 11450, sell: 11580 }
    };

    const rateDoc = {
      type: 'current',
      rates: defaultRates,
      updated_at: new Date(),
      source: 'default',
      is_live: false
    };

    await tenantDB.collection('exchange_rates').insertOne(rateDoc);
    return rateDoc;
  }

  async updateTenantRates(tenantDB, liveRates) {
    // دریافت تنظیمات markup
    const markupSettings = await this.getMarkupSettings(tenantDB);
    
    const tenantRates = {};
    for (const [pair, rate] of Object.entries(liveRates)) {
      if (pair !== 'updated_at') {
        const markup = markupSettings[pair] || { buy: 0.01, sell: 0.015 };
        tenantRates[pair] = {
          buy: rate * (1 - markup.buy),
          sell: rate * (1 + markup.sell)
        };
      }
    }

    const rateDoc = {
      type: 'current',
      rates: tenantRates,
      updated_at: new Date(),
      source: 'api',
      is_live: true
    };

    await tenantDB.collection('exchange_rates').updateOne(
      { type: 'current' },
      { $set: rateDoc },
      { upsert: true }
    );

    return rateDoc;
  }

  async getMarkupSettings(tenantDB) {
    const settings = await tenantDB.collection('settings').findOne({
      type: 'exchange_markup'
    });

    return settings?.markup || {
      USD_IRR: { buy: 0.01, sell: 0.015 },
      EUR_IRR: { buy: 0.01, sell: 0.015 },
      GBP_IRR: { buy: 0.01, sell: 0.015 },
      AED_IRR: { buy: 0.01, sell: 0.015 }
    };
  }

  applyMarkup(rates, markupSettings) {
    const markedupRates = {};
    
    for (const [pair, rate] of Object.entries(rates)) {
      const markup = markupSettings[pair] || { buy: 0.01, sell: 0.015 };
      
      if (typeof rate === 'object' && rate.buy && rate.sell) {
        markedupRates[pair] = {
          buy: rate.buy * (1 - markup.buy),
          sell: rate.sell * (1 + markup.sell)
        };
      } else if (typeof rate === 'number') {
        markedupRates[pair] = {
          buy: rate * (1 - markup.buy),
          sell: rate * (1 + markup.sell)
        };
      }
    }

    return markedupRates;
  }

  calculateRateChanges(currentRates, previousRates) {
    if (!previousRates) return {};

    const changes = {};
    for (const [pair, current] of Object.entries(currentRates)) {
      const previous = previousRates[pair];
      if (previous && typeof current === 'object' && typeof previous === 'object') {
        changes[pair] = {
          buy_change: ((current.buy - previous.buy) / previous.buy * 100).toFixed(2),
          sell_change: ((current.sell - previous.sell) / previous.sell * 100).toFixed(2),
          buy_direction: current.buy > previous.buy ? 'up' : current.buy < previous.buy ? 'down' : 'stable',
          sell_direction: current.sell > previous.sell ? 'up' : current.sell < previous.sell ? 'down' : 'stable'
        };
      }
    }

    return changes;
  }

  formatRatesDisplay(rates) {
    const formatted = {};
    for (const [pair, rate] of Object.entries(rates)) {
      if (typeof rate === 'object' && rate.buy && rate.sell) {
        formatted[pair] = {
          buy: formatCurrency(rate.buy, 'IRR'),
          sell: formatCurrency(rate.sell, 'IRR'),
          spread: ((rate.sell - rate.buy) / rate.buy * 100).toFixed(2) + '%'
        };
      }
    }
    return formatted;
  }

  validateRates(rates) {
    const errors = [];
    const validCurrencyPairs = ['USD_IRR', 'EUR_IRR', 'GBP_IRR', 'AED_IRR'];

    for (const [pair, rate] of Object.entries(rates)) {
      if (!validCurrencyPairs.includes(pair)) {
        errors.push(`Invalid currency pair: ${pair}`);
        continue;
      }

      if (typeof rate === 'object') {
        if (!rate.buy || !rate.sell || rate.buy <= 0 || rate.sell <= 0) {
          errors.push(`Invalid rates for ${pair}: buy and sell must be positive numbers`);
        }
        if (rate.sell <= rate.buy) {
          errors.push(`Invalid rates for ${pair}: sell rate must be higher than buy rate`);
        }
      } else if (typeof rate === 'number') {
        if (rate <= 0) {
          errors.push(`Invalid rate for ${pair}: must be a positive number`);
        }
      } else {
        errors.push(`Invalid rate format for ${pair}`);
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  async saveRateHistory(tenantDB, rates, source, userId) {
    const historyEntries = [];
    
    for (const [pair, rate] of Object.entries(rates)) {
      if (typeof rate === 'object' && rate.buy && rate.sell) {
        historyEntries.push({
          currency_pair: pair,
          buy_rate: rate.buy,
          sell_rate: rate.sell,
          source,
          created_by: userId,
          created_at: new Date(),
          jalaali_date: moment().format('jYYYY/jMM/jDD HH:mm')
        });
      }
    }

    if (historyEntries.length > 0) {
      await tenantDB.collection('rate_history').insertMany(historyEntries);
    }
  }

  async checkRateAlerts(tenantDB, rates) {
    try {
      const alerts = await tenantDB.collection('rate_alerts').find({
        is_active: true
      }).toArray();

      for (const alert of alerts) {
        const currentRate = rates[alert.currency_pair];
        if (!currentRate) continue;

        const rateToCheck = typeof currentRate === 'object' ? currentRate.buy : currentRate;
        let shouldTrigger = false;

        if (alert.type === 'above' && rateToCheck >= alert.threshold) {
          shouldTrigger = true;
        } else if (alert.type === 'below' && rateToCheck <= alert.threshold) {
          shouldTrigger = true;
        }

        if (shouldTrigger) {
          await this.triggerRateAlert(tenantDB, alert, rateToCheck);
        }
      }
    } catch (error) {
      logger.warn('Rate alert check failed:', error);
    }
  }

  async triggerRateAlert(tenantDB, alert, currentRate) {
    // Update alert triggered count
    await tenantDB.collection('rate_alerts').updateOne(
      { _id: alert._id },
      {
        $inc: { triggered_count: 1 },
        $set: { last_triggered: new Date() }
      }
    );

    // Send notification (implementation depends on notification method)
    logger.info(`Rate alert triggered`, {
      alertId: alert._id,
      currency_pair: alert.currency_pair,
      threshold: alert.threshold,
      current_rate: currentRate,
      type: alert.type
    });

    // Here you would integrate with email/SMS service
  }

  getIntervalGrouping(interval) {
    switch (interval) {
      case 'hourly':
        return {
          year: { $year: '$created_at' },
          month: { $month: '$created_at' },
          day: { $dayOfMonth: '$created_at' },
          hour: { $hour: '$created_at' }
        };
      case 'daily':
        return {
          year: { $year: '$created_at' },
          month: { $month: '$created_at' },
          day: { $dayOfMonth: '$created_at' }
        };
      case 'weekly':
        return {
          year: { $year: '$created_at' },
          week: { $week: '$created_at' }
        };
      case 'monthly':
        return {
          year: { $year: '$created_at' },
          month: { $month: '$created_at' }
        };
      default:
        return {
          year: { $year: '$created_at' },
          month: { $month: '$created_at' },
          day: { $dayOfMonth: '$created_at' }
        };
    }
  }

  calculateRateStatistics(history) {
    if (!history.length) return {};

    const buyRates = history.map(h => h.buy_rate).filter(Boolean);
    const sellRates = history.map(h => h.sell_rate).filter(Boolean);

    return {
      buy_rates: {
        min: Math.min(...buyRates),
        max: Math.max(...buyRates),
        avg: buyRates.reduce((a, b) => a + b, 0) / buyRates.length,
        volatility: this.calculateVolatility(buyRates)
      },
      sell_rates: {
        min: Math.min(...sellRates),
        max: Math.max(...sellRates),
        avg: sellRates.reduce((a, b) => a + b, 0) / sellRates.length,
        volatility: this.calculateVolatility(sellRates)
      },
      data_points: history.length
    };
  }

  calculateVolatility(rates) {
    if (rates.length < 2) return 0;
    
    const mean = rates.reduce((a, b) => a + b, 0) / rates.length;
    const squaredDiffs = rates.map(rate => Math.pow(rate - mean, 2));
    const variance = squaredDiffs.reduce((a, b) => a + b, 0) / rates.length;
    return Math.sqrt(variance);
  }

  formatChartData(history) {
    return history.map(item => ({
      date: item.date,
      buy: item.buy_rate,
      sell: item.sell_rate,
      high: item.high,
      low: item.low
    }));
  }
}

module.exports = new ExchangeRateController();