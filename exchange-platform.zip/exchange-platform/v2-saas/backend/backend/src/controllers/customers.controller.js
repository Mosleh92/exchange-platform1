const { validationResult } = require('express-validator');
const mongoose = require('mongoose');
const moment = require('moment-jalaali');
const logger = require('../utils/logger');
const { generateCustomerCode, validateNationalId, formatCurrency } = require('../utils/helpers');

class CustomerController {
  // ایجاد مشتری جدید
  async createCustomer(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const tenantDB = req.tenant.db;
      const {
        name,
        phone,
        email = '',
        national_id = '',
        address = '',
        credit_limit = 0,
        preferred_currency = 'USD',
        kyc_documents = [],
        notes = ''
      } = req.body;

      // بررسی تکراری نبودن
      const existingCustomer = await tenantDB.collection('customers').findOne({
        $or: [
          { phone: phone.replace(/\s/g, '') },
          ...(email ? [{ email: email.toLowerCase() }] : []),
          ...(national_id ? [{ national_id }] : [])
        ]
      });

      if (existingCustomer) {
        const duplicateField = existingCustomer.phone === phone.replace(/\s/g, '') ? 'phone' : 
                              existingCustomer.email === email.toLowerCase() ? 'email' : 'national_id';
        
        return res.status(409).json({
          error: 'Customer already exists',
          code: 'CUSTOMER_EXISTS',
          field: duplicateField
        });
      }

      // اعتبارسنجی کد ملی
      if (national_id && !validateNationalId(national_id)) {
        return res.status(400).json({
          error: 'Invalid national ID',
          code: 'INVALID_NATIONAL_ID'
        });
      }

      const customer = {
        customer_code: generateCustomerCode(),
        name: name.trim(),
        phone: phone.replace(/\s/g, ''),
        email: email.toLowerCase().trim(),
        national_id,
        address,
        credit_limit: parseFloat(credit_limit),
        current_balance: 0,
        preferred_currency,
        kyc_status: national_id ? 'pending' : 'basic',
        kyc_documents,
        status: 'active',
        notes,
        created_by: req.user.userId,
        created_by_name: req.user.name,
        created_at: new Date(),
        updated_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD'),
        metadata: {
          total_transactions: 0,
          total_volume_usd: 0,
          total_commission_paid: 0,
          last_transaction: null,
          risk_level: 'low',
          vip_status: false,
          source: 'manual_registration'
        }
      };

      const result = await tenantDB.collection('customers').insertOne(customer);

      // ایجاد حساب مشتری
      await tenantDB.collection('customer_accounts').insertOne({
        customer_id: result.insertedId,
        customer_code: customer.customer_code,
        balances: {
          USD: 0,
          EUR: 0,
          GBP: 0,
          AED: 0,
          IRR: 0
        },
        credit_used: 0,
        credit_available: customer.credit_limit,
        account_status: 'active',
        created_at: new Date(),
        updated_at: new Date()
      });

      logger.info(`Customer created`, {
        tenantId: req.tenant.id,
        customerId: result.insertedId,
        customerCode: customer.customer_code,
        name: customer.name,
        userId: req.user.userId
      });

      res.status(201).json({
        success: true,
        message: 'Customer created successfully',
        data: {
          customer_id: result.insertedId,
          customer_code: customer.customer_code,
          name: customer.name,
          phone: customer.phone,
          kyc_status: customer.kyc_status,
          credit_limit: customer.credit_limit
        }
      });

    } catch (error) {
      logger.error('Create customer error:', error);
      res.status(500).json({
        error: 'Failed to create customer',
        code: 'CUSTOMER_CREATE_ERROR',
        message: error.message
      });
    }
  }

  // لیست مشتریان
  async getCustomers(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        page = 1,
        limit = 20,
        search = '',
        status = 'active',
        kyc_status,
        risk_level,
        vip_status,
        sort_by = 'created_at',
        sort_order = 'desc'
      } = req.query;

      // ساخت فیلتر
      const filter = { status };
      
      if (kyc_status) filter.kyc_status = kyc_status;
      if (risk_level) filter['metadata.risk_level'] = risk_level;
      if (vip_status !== undefined) filter['metadata.vip_status'] = vip_status === 'true';
      
      if (search) {
        filter.$or = [
          { name: { $regex: search, $options: 'i' } },
          { phone: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } },
          { customer_code: { $regex: search, $options: 'i' } },
          { national_id: { $regex: search, $options: 'i' } }
        ];
      }

      // تنظیم مرتب‌سازی
      const sortOptions = {};
      sortOptions[sort_by] = sort_order === 'desc' ? -1 : 1;

      // اجرای کوئری
      const skip = (parseInt(page) - 1) * parseInt(limit);
      const customers = await tenantDB.collection('customers')
        .find(filter)
        .sort(sortOptions)
        .skip(skip)
        .limit(parseInt(limit))
        .toArray();

      // افزودن اطلاعات حساب و آمار
      for (let customer of customers) {
        const account = await tenantDB.collection('customer_accounts').findOne({
          customer_id: customer._id
        });

        const recentTransactions = await tenantDB.collection('transactions')
          .find({ customer_id: customer._id })
          .sort({ created_at: -1 })
          .limit(5)
          .toArray();

        customer.account = account || { balances: {}, credit_used: 0 };
        customer.recent_transactions = recentTransactions;
        customer.formatted_balance = formatCurrency(customer.current_balance);
      }

      const totalCustomers = await tenantDB.collection('customers').countDocuments(filter);

      // آمار کلی
      const stats = await tenantDB.collection('customers').aggregate([
        { $match: { status: 'active' } },
        {
          $group: {
            _id: null,
            total_customers: { $sum: 1 },
            total_credit_limit: { $sum: '$credit_limit' },
            total_balance: { $sum: '$current_balance' },
            vip_customers: {
              $sum: { $cond: ['$metadata.vip_status', 1, 0] }
            },
            kyc_pending: {
              $sum: { $cond: [{ $eq: ['$kyc_status', 'pending'] }, 1, 0] }
            }
          }
        }
      ]).toArray();

      res.json({
        success: true,
        data: {
          customers,
          pagination: {
            page: parseInt(page),
            limit: parseInt(limit),
            total: totalCustomers,
            pages: Math.ceil(totalCustomers / parseInt(limit))
          },
          stats: stats[0] || {
            total_customers: 0,
            total_credit_limit: 0,
            total_balance: 0,
            vip_customers: 0,
            kyc_pending: 0
          }
        }
      });

    } catch (error) {
      logger.error('Get customers error:', error);
      res.status(500).json({
        error: 'Failed to fetch customers',
        code: 'CUSTOMERS_FETCH_ERROR'
      });
    }
  }

  // جزئیات مشتری
  async getCustomerById(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { id } = req.params;

      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      // اطلاعات حساب
      const account = await tenantDB.collection('customer_accounts').findOne({
        customer_id: customer._id
      });

      // تاریخچه معاملات
      const transactions = await tenantDB.collection('transactions')
        .find({ customer_id: customer._id })
        .sort({ created_at: -1 })
        .limit(50)
        .toArray();

      // آمار مشتری
      const stats = await tenantDB.collection('transactions').aggregate([
        { $match: { customer_id: customer._id, status: 'completed' } },
        {
          $group: {
            _id: null,
            total_transactions: { $sum: 1 },
            total_volume: { $sum: '$amount_from' },
            total_commission: { $sum: '$commission' },
            avg_transaction: { $avg: '$amount_from' },
            buy_count: {
              $sum: { $cond: [{ $eq: ['$type', 'buy'] }, 1, 0] }
            },
            sell_count: {
              $sum: { $cond: [{ $eq: ['$type', 'sell'] }, 1, 0] }
            },
            currencies_used: { $addToSet: '$currency_from' }
          }
        }
      ]).toArray();

      // تحلیل رفتار مشتری
      const behavior = await this.analyzeCustomerBehavior(tenantDB, customer._id);

      res.json({
        success: true,
        data: {
          customer: {
            ...customer,
            formatted_balance: formatCurrency(customer.current_balance),
            formatted_credit_limit: formatCurrency(customer.credit_limit)
          },
          account,
          transactions,
          stats: stats[0] || {
            total_transactions: 0,
            total_volume: 0,
            total_commission: 0,
            avg_transaction: 0,
            buy_count: 0,
            sell_count: 0,
            currencies_used: []
          },
          behavior
        }
      });

    } catch (error) {
      logger.error('Get customer by ID error:', error);
      res.status(500).json({
        error: 'Failed to fetch customer details',
        code: 'CUSTOMER_DETAIL_ERROR'
      });
    }
  }

  // به‌روزرسانی مشتری
  async updateCustomer(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const tenantDB = req.tenant.db;
      const { id } = req.params;
      const {
        name,
        phone,
        email,
        national_id,
        address,
        credit_limit,
        preferred_currency,
        notes,
        kyc_status,
        status
      } = req.body;

      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      // بررسی تکراری نبودن (به جز خود مشتری)
      if (phone || email || national_id) {
        const duplicateFilter = {
          _id: { $ne: customer._id },
          $or: []
        };

        if (phone) duplicateFilter.$or.push({ phone: phone.replace(/\s/g, '') });
        if (email) duplicateFilter.$or.push({ email: email.toLowerCase() });
        if (national_id) duplicateFilter.$or.push({ national_id });

        if (duplicateFilter.$or.length > 0) {
          const duplicate = await tenantDB.collection('customers').findOne(duplicateFilter);
          if (duplicate) {
            return res.status(409).json({
              error: 'Customer with this information already exists',
              code: 'CUSTOMER_EXISTS'
            });
          }
        }
      }

      // اعتبارسنجی کد ملی
      if (national_id && !validateNationalId(national_id)) {
        return res.status(400).json({
          error: 'Invalid national ID',
          code: 'INVALID_NATIONAL_ID'
        });
      }

      const updateData = {
        ...(name && { name: name.trim() }),
        ...(phone && { phone: phone.replace(/\s/g, '') }),
        ...(email !== undefined && { email: email.toLowerCase().trim() }),
        ...(national_id !== undefined && { national_id }),
        ...(address !== undefined && { address }),
        ...(credit_limit !== undefined && { credit_limit: parseFloat(credit_limit) }),
        ...(preferred_currency && { preferred_currency }),
        ...(notes !== undefined && { notes }),
        ...(kyc_status && { kyc_status }),
        ...(status && { status }),
        updated_at: new Date(),
        updated_by: req.user.userId,
        updated_by_name: req.user.name
      };

      await tenantDB.collection('customers').updateOne(
        { _id: customer._id },
        { $set: updateData }
      );

      // به‌روزرسانی حساب مشتری
      if (credit_limit !== undefined) {
        await tenantDB.collection('customer_accounts').updateOne(
          { customer_id: customer._id },
          {
            $set: {
              credit_available: parseFloat(credit_limit) - (customer.current_balance || 0),
              updated_at: new Date()
            }
          }
        );
      }

      logger.info(`Customer updated`, {
        tenantId: req.tenant.id,
        customerId: customer._id,
        updates: Object.keys(updateData),
        userId: req.user.userId
      });

      res.json({
        success: true,
        message: 'Customer updated successfully',
        data: {
          customer_id: customer._id,
          updated_fields: Object.keys(updateData)
        }
      });

    } catch (error) {
      logger.error('Update customer error:', error);
      res.status(500).json({
        error: 'Failed to update customer',
        code: 'CUSTOMER_UPDATE_ERROR'
      });
    }
  }

  // حذف مشتری
  async deleteCustomer(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { id } = req.params;

      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      // بررسی وجود معاملات
      const transactionCount = await tenantDB.collection('transactions').countDocuments({
        customer_id: customer._id,
        status: 'completed'
      });

      if (transactionCount > 0) {
        // اگر معاملات دارد، فقط غیرفعال کن
        await tenantDB.collection('customers').updateOne(
          { _id: customer._id },
          {
            $set: {
              status: 'inactive',
              deleted_at: new Date(),
              deleted_by: req.user.userId,
              delete_reason: 'Customer deletion with existing transactions'
            }
          }
        );

        logger.info(`Customer deactivated`, {
          tenantId: req.tenant.id,
          customerId: customer._id,
          reason: 'Has existing transactions',
          userId: req.user.userId
        });

        res.json({
          success: true,
          message: 'Customer deactivated (has existing transactions)',
          data: { customer_id: customer._id, status: 'inactive' }
        });
      } else {
        // حذف کامل
        await tenantDB.collection('customers').deleteOne({ _id: customer._id });
        await tenantDB.collection('customer_accounts').deleteOne({ customer_id: customer._id });

        logger.info(`Customer deleted`, {
          tenantId: req.tenant.id,
          customerId: customer._id,
          userId: req.user.userId
        });

        res.json({
          success: true,
          message: 'Customer deleted successfully',
          data: { customer_id: customer._id }
        });
      }

    } catch (error) {
      logger.error('Delete customer error:', error);
      res.status(500).json({
        error: 'Failed to delete customer',
        code: 'CUSTOMER_DELETE_ERROR'
      });
    }
  }

  // معاملات مشتری
  async getCustomerTransactions(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { id } = req.params;
      const {
        page = 1,
        limit = 20,
        type,
        start_date,
        end_date,
        status = 'completed'
      } = req.query;

      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      // ساخت فیلتر
      const filter = {
        customer_id: customer._id,
        status
      };

      if (type) filter.type = type;
      if (start_date || end_date) {
        filter.created_at = {};
        if (start_date) filter.created_at.$gte = new Date(start_date);
        if (end_date) filter.created_at.$lte = new Date(end_date);
      }

      // اجرای کوئری
      const skip = (parseInt(page) - 1) * parseInt(limit);
      const transactions = await tenantDB.collection('transactions')
        .find(filter)
        .sort({ created_at: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .toArray();

      const totalTransactions = await tenantDB.collection('transactions').countDocuments(filter);

      // آمار معاملات مشتری
      const stats = await tenantDB.collection('transactions').aggregate([
        { $match: { customer_id: customer._id, status: 'completed' } },
        {
          $group: {
            _id: '$type',
            count: { $sum: 1 },
            total_volume: { $sum: '$amount_from' },
            total_commission: { $sum: '$commission' },
            avg_amount: { $avg: '$amount_from' }
          }
        }
      ]).toArray();

      res.json({
        success: true,
        data: {
          customer: {
            id: customer._id,
            name: customer.name,
            customer_code: customer.customer_code
          },
          transactions,
          pagination: {
            page: parseInt(page),
            limit: parseInt(limit),
            total: totalTransactions,
            pages: Math.ceil(totalTransactions / parseInt(limit))
          },
          stats: {
            buy: stats.find(s => s._id === 'buy') || { count: 0, total_volume: 0, total_commission: 0, avg_amount: 0 },
            sell: stats.find(s => s._id === 'sell') || { count: 0, total_volume: 0, total_commission: 0, avg_amount: 0 }
          }
        }
      });

    } catch (error) {
      logger.error('Get customer transactions error:', error);
      res.status(500).json({
        error: 'Failed to fetch customer transactions',
        code: 'CUSTOMER_TRANSACTIONS_ERROR'
      });
    }
  }

  // تنظیم موجودی مشتری
  async adjustCustomerBalance(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const tenantDB = req.tenant.db;
      const { id } = req.params;
      const { amount, reason, type } = req.body;

      const customer = await tenantDB.collection('customers').findOne({
        _id: new mongoose.Types.ObjectId(id)
      });

      if (!customer) {
        return res.status(404).json({
          error: 'Customer not found',
          code: 'CUSTOMER_NOT_FOUND'
        });
      }

      const adjustmentAmount = type === 'credit' ? parseFloat(amount) : -parseFloat(amount);
      const newBalance = (customer.current_balance || 0) + adjustmentAmount;

      // ثبت تنظیم موجودی
      const adjustment = {
        customer_id: customer._id,
        customer_name: customer.name,
        type,
        amount: parseFloat(amount),
        adjustment_amount: adjustmentAmount,
        previous_balance: customer.current_balance || 0,
        new_balance: newBalance,
        reason,
        created_by: req.user.userId,
        created_by_name: req.user.name,
        created_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD')
      };

      await tenantDB.collection('balance_adjustments').insertOne(adjustment);

      // به‌روزرسانی موجودی مشتری
      await tenantDB.collection('customers').updateOne(
        { _id: customer._id },
        {
          $set: {
            current_balance: newBalance,
            updated_at: new Date()
          }
        }
      );

      // به‌روزرسانی حساب مشتری
      await tenantDB.collection('customer_accounts').updateOne(
        { customer_id: customer._id },
        {
          $set: {
            credit_available: customer.credit_limit - newBalance,
            updated_at: new Date()
          }
        }
      );

      logger.info(`Customer balance adjusted`, {
        tenantId: req.tenant.id,
        customerId: customer._id,
        type,
        amount: adjustmentAmount,
        newBalance,
        userId: req.user.userId
      });

      res.json({
        success: true,
        message: 'Customer balance adjusted successfully',
        data: {
          customer_id: customer._id,
          previous_balance: customer.current_balance || 0,
          adjustment_amount: adjustmentAmount,
          new_balance: newBalance,
          formatted_new_balance: formatCurrency(newBalance)
        }
      });

    } catch (error) {
      logger.error('Adjust customer balance error:', error);
      res.status(500).json({
        error: 'Failed to adjust customer balance',
        code: 'BALANCE_ADJUSTMENT_ERROR'
      });
    }
  }

  // تحلیل رفتار مشتری
  async analyzeCustomerBehavior(tenantDB, customerId) {
    try {
      const now = new Date();
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      const last3Months = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());

      // فعالیت ماهانه
      const monthlyActivity = await tenantDB.collection('transactions').aggregate([
        { 
          $match: { 
            customer_id: customerId, 
            status: 'completed',
            created_at: { $gte: last3Months }
          } 
        },
        {
          $group: {
            _id: {
              year: { $year: '$created_at' },
              month: { $month: '$created_at' }
            },
            transaction_count: { $sum: 1 },
            total_volume: { $sum: '$amount_from' },
            avg_amount: { $avg: '$amount_from' }
          }
        },
        { $sort: { '_id.year': 1, '_id.month': 1 } }
      ]).toArray();

      // ترجیحات ارزی
      const currencyPreferences = await tenantDB.collection('transactions').aggregate([
        { $match: { customer_id: customerId, status: 'completed' } },
        {
          $group: {
            _id: '$currency_from',
            count: { $sum: 1 },
            total_volume: { $sum: '$amount_from' }
          }
        },
        { $sort: { count: -1 } }
      ]).toArray();

      // الگوی زمانی
      const timePattern = await tenantDB.collection('transactions').aggregate([
        { $match: { customer_id: customerId, status: 'completed' } },
        {
          $group: {
            _id: { $hour: '$created_at' },
            count: { $sum: 1 }
          }
        },
        { $sort: { '_id': 1 } }
      ]).toArray();

      // ارزیابی ریسک
      const riskFactors = {
        high_volume_transactions: monthlyActivity.some(m => m.total_volume > 50000),
        irregular_patterns: monthlyActivity.length > 0 ? 
          (Math.max(...monthlyActivity.map(m => m.transaction_count)) / 
           Math.min(...monthlyActivity.map(m => m.transaction_count))) > 3 : false,
        new_customer: (now - new Date(customerId.getTimestamp())) < (30 * 24 * 60 * 60 * 1000) // 30 days
      };

      const riskScore = Object.values(riskFactors).filter(Boolean).length;
      const riskLevel = riskScore === 0 ? 'low' : riskScore === 1 ? 'medium' : 'high';

      return {
        monthly_activity: monthlyActivity,
        currency_preferences: currencyPreferences,
        time_pattern: timePattern,
        risk_assessment: {
          risk_level: riskLevel,
          risk_score: riskScore,
          factors: riskFactors
        },
        recommendations: this.generateCustomerRecommendations(monthlyActivity, currencyPreferences, riskLevel)
      };

    } catch (error) {
      logger.warn('Customer behavior analysis failed:', error);
      return {
        monthly_activity: [],
        currency_preferences: [],
        time_pattern: [],
        risk_assessment: { risk_level: 'unknown', risk_score: 0, factors: {} },
        recommendations: []
      };
    }
  }

  generateCustomerRecommendations(monthlyActivity, currencyPreferences, riskLevel) {
    const recommendations = [];

    if (monthlyActivity.length > 0) {
      const avgVolume = monthlyActivity.reduce((sum, m) => sum + m.total_volume, 0) / monthlyActivity.length;
      
      if (avgVolume > 10000) {
        recommendations.push({
          type: 'vip_upgrade',
          message: 'Customer qualifies for VIP status',
          priority: 'high'
        });
      }

      if (monthlyActivity[monthlyActivity.length - 1]?.transaction_count < 2) {
        recommendations.push({
          type: 'engagement',
          message: 'Customer activity has decreased',
          priority: 'medium'
        });
      }
    }

    if (currencyPreferences.length > 3) {
      recommendations.push({
        type: 'diversification',
        message: 'Customer uses multiple currencies',
        priority: 'low'
      });
    }

    if (riskLevel === 'high') {
      recommendations.push({
        type: 'kyc_review',
        message: 'Customer requires enhanced KYC review',
        priority: 'high'
      });
    }

    return recommendations;
  }
}

module.exports = new CustomerController();