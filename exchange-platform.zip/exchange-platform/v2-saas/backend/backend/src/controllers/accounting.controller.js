const moment = require('moment-jalaali');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const logger = require('../utils/logger');
const { formatCurrency, formatJalaliDate } = require('../utils/helpers');

class AccountingController {
  // گزارش سود و زیان
  async getProfitLossReport(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        start_date = moment().startOf('month').toDate(),
        end_date = moment().endOf('month').toDate(),
        group_by = 'daily',
        currency = 'IRR'
      } = req.query;

      const dateFilter = {
        created_at: {
          $gte: new Date(start_date),
          $lte: new Date(end_date)
        }
      };

      // درآمد از کارمزدها
      const commissionRevenue = await tenantDB.collection('transactions').aggregate([
        { $match: { ...dateFilter, status: 'completed' } },
        {
          $group: {
            _id: {
              date: this.getGroupingExpression(group_by),
              type: '$type'
            },
            total_commission: { $sum: '$commission' },
            total_volume: { $sum: '$amount_from' },
            transaction_count: { $sum: 1 },
            avg_commission: { $avg: '$commission' }
          }
        },
        { $sort: { '_id.date': 1 } }
      ]).toArray();

      // هزینه‌ها
      const expenses = await tenantDB.collection('accounting_entries').aggregate([
        { 
          $match: { 
            ...dateFilter, 
            type: 'expense',
            currency 
          } 
        },
        {
          $group: {
            _id: {
              date: this.getGroupingExpression(group_by),
              category: '$category'
            },
            total_amount: { $sum: '$amount' },
            count: { $sum: 1 },
            avg_amount: { $avg: '$amount' }
          }
        },
        { $sort: { '_id.date': 1 } }
      ]).toArray();

      // سایر درآمدها
      const otherRevenue = await tenantDB.collection('accounting_entries').aggregate([
        { 
          $match: { 
            ...dateFilter, 
            type: 'revenue',
            category: { $ne: 'commission' },
            currency 
          } 
        },
        {
          $group: {
            _id: {
              date: this.getGroupingExpression(group_by),
              category: '$category'
            },
            total_amount: { $sum: '$amount' },
            count: { $sum: 1 }
          }
        },
        { $sort: { '_id.date': 1 } }
      ]).toArray();

      // محاسبه خلاصه
      const summary = this.calculateProfitLossSummary(commissionRevenue, expenses, otherRevenue);

      // تحلیل ترند
      const trends = this.calculateTrends(commissionRevenue, expenses, group_by);

      res.json({
        success: true,
        data: {
          period: {
            start_date,
            end_date,
            group_by,
            currency
          },
          summary,
          trends,
          details: {
            commission_revenue: commissionRevenue,
            expenses,
            other_revenue: otherRevenue
          },
          generated_at: new Date(),
          generated_by: req.user.name
        }
      });

    } catch (error) {
      logger.error('Profit loss report error:', error);
      res.status(500).json({
        error: 'Failed to generate profit/loss report',
        code: 'PROFIT_LOSS_ERROR'
      });
    }
  }

  // گزارش جریان نقدی
  async getCashFlowReport(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        start_date = moment().startOf('month').toDate(),
        end_date = moment().endOf('month').toDate(),
        currency = 'all'
      } = req.query;

      const dateFilter = {
        created_at: {
          $gte: new Date(start_date),
          $lte: new Date(end_date)
        }
      };

      // جریان نقدی از معاملات
      const transactionFlow = await tenantDB.collection('transactions').aggregate([
        { $match: { ...dateFilter, status: 'completed' } },
        {
          $group: {
            _id: '$currency_to',
            cash_in: {
              $sum: {
                $cond: [
                  { $eq: ['$type', 'sell'] },
                  { $subtract: ['$amount_to', '$commission'] },
                  0
                ]
              }
            },
            cash_out: {
              $sum: {
                $cond: [
                  { $eq: ['$type', 'buy'] },
                  { $add: ['$amount_to', '$commission'] },
                  0
                ]
              }
            },
            commission_earned: { $sum: '$commission' },
            transaction_count: { $sum: 1 }
          }
        }
      ]).toArray();

      // سایر تراکنش‌های نقدی
      const otherCashFlow = await tenantDB.collection('accounting_entries').aggregate([
        { $match: dateFilter },
        {
          $group: {
            _id: '$currency',
            cash_in: {
              $sum: {
                $cond: [
                  { $eq: ['$type', 'revenue'] },
                  '$amount',
                  0
                ]
              }
            },
            cash_out: {
              $sum: {
                $cond: [
                  { $eq: ['$type', 'expense'] },
                  '$amount',
                  0
                ]
              }
            },
            entry_count: { $sum: 1 }
          }
        }
      ]).toArray();

      // موجودی فعلی صندوق
      const cashBoxBalance = await tenantDB.collection('cash_box').find({}).toArray();

      // پیش‌بینی جریان نقدی
      const forecast = await this.generateCashFlowForecast(tenantDB, dateFilter);

      res.json({
        success: true,
        data: {
          period: { start_date, end_date },
          transaction_flow: transactionFlow,
          other_cash_flow: otherCashFlow,
          current_balances: cashBoxBalance,
          net_flow: this.calculateNetCashFlow(transactionFlow, otherCashFlow),
          forecast,
          summary: {
            total_cash_in: this.sumCashFlow(transactionFlow, otherCashFlow, 'in'),
            total_cash_out: this.sumCashFlow(transactionFlow, otherCashFlow, 'out'),
            net_cash_flow: this.calculateNetCashFlow(transactionFlow, otherCashFlow)
          }
        }
      });

    } catch (error) {
      logger.error('Cash flow report error:', error);
      res.status(500).json({
        error: 'Failed to generate cash flow report',
        code: 'CASH_FLOW_ERROR'
      });
    }
  }

  // ترازنامه
  async getBalanceSheet(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { date = new Date() } = req.query;

      const balanceDate = new Date(date);
      balanceDate.setHours(23, 59, 59, 999);

      // دارایی‌ها
      const assets = await this.calculateAssets(tenantDB, balanceDate);
      
      // بدهی‌ها
      const liabilities = await this.calculateLiabilities(tenantDB, balanceDate);
      
      // حقوق صاحبان سهام
      const equity = await this.calculateEquity(tenantDB, balanceDate);

      res.json({
        success: true,
        data: {
          date: balanceDate,
          assets,
          liabilities,
          equity,
          balance_check: {
            assets_total: assets.total,
            liabilities_equity_total: liabilities.total + equity.total,
            is_balanced: Math.abs((assets.total) - (liabilities.total + equity.total)) < 0.01
          }
        }
      });

    } catch (error) {
      logger.error('Balance sheet error:', error);
      res.status(500).json({
        error: 'Failed to generate balance sheet',
        code: 'BALANCE_SHEET_ERROR'
      });
    }
  }

  // خلاصه روزانه
  async getDailySummary(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const { date = new Date().toISOString().split('T')[0] } = req.query;

      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);

      const dateFilter = {
        created_at: { $gte: startDate, $lt: endDate }
      };

      // معاملات روزانه
      const dailyTransactions = await tenantDB.collection('transactions').aggregate([
        { $match: { ...dateFilter, status: 'completed' } },
        {
          $group: {
            _id: '$type',
            count: { $sum: 1 },
            total_volume: { $sum: '$amount_from' },
            total_commission: { $sum: '$commission' },
            avg_amount: { $avg: '$amount_from' },
            currencies: { $addToSet: '$currency_from' }
          }
        }
      ]).toArray();

      // مشتریان جدید
      const newCustomers = await tenantDB.collection('customers').countDocuments({
        created_at: dateFilter.created_at
      });

      // موجودی صندوق
      const cashBalances = await tenantDB.collection('cash_box').find({}).toArray();

      // هزینه‌های روزانه
      const dailyExpenses = await tenantDB.collection('accounting_entries').aggregate([
        { $match: { ...dateFilter, type: 'expense' } },
        {
          $group: {
            _id: '$category',
            total: { $sum: '$amount' },
            count: { $sum: 1 }
          }
        }
      ]).toArray();

      // کارایی عملیاتی
      const performance = this.calculateDailyPerformance(dailyTransactions, dailyExpenses);

      res.json({
        success: true,
        data: {
          date,
          transactions: {
            summary: dailyTransactions,
            total_count: dailyTransactions.reduce((sum, t) => sum + t.count, 0),
            total_commission: dailyTransactions.reduce((sum, t) => sum + t.total_commission, 0)
          },
          customers: {
            new_registrations: newCustomers
          },
          cash_balances: cashBalances,
          expenses: {
            categories: dailyExpenses,
            total: dailyExpenses.reduce((sum, e) => sum + e.total, 0)
          },
          performance,
          jalaali_date: moment(startDate).format('jYYYY/jMM/jDD')
        }
      });

    } catch (error) {
      logger.error('Daily summary error:', error);
      res.status(500).json({
        error: 'Failed to generate daily summary',
        code: 'DAILY_SUMMARY_ERROR'
      });
    }
  }

  // ثبت هزینه
  async recordExpense(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        amount,
        currency = 'IRR',
        category,
        description,
        payment_method = 'cash',
        receipt_number,
        vendor_name = '',
        notes = '',
        due_date = null
      } = req.body;

      const expense = {
        type: 'expense',
        amount: parseFloat(amount),
        currency,
        category,
        description,
        payment_method,
        receipt_number,
        vendor_name,
        notes,
        due_date: due_date ? new Date(due_date) : null,
        created_by: req.user.userId,
        created_by_name: req.user.name,
        created_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD'),
        status: 'completed',
        metadata: {
          ip_address: req.ip,
          user_agent: req.get('User-Agent')
        }
      };

      const result = await tenantDB.collection('accounting_entries').insertOne(expense);

      // به‌روزرسانی صندوق
      await tenantDB.collection('cash_box').updateOne(
        { currency },
        {
          $inc: { balance: -parseFloat(amount) },
          $set: { updated_at: new Date() },
          $push: {
            transactions: {
              entry_id: result.insertedId,
              amount: -parseFloat(amount),
              type: 'expense',
              description,
              timestamp: new Date()
            }
          }
        },
        { upsert: true }
      );

      logger.info(`Expense recorded`, {
        tenantId: req.tenant.id,
        expenseId: result.insertedId,
        amount,
        category,
        userId: req.user.userId
      });

      res.status(201).json({
        success: true,
        message: 'Expense recorded successfully',
        data: {
          expense_id: result.insertedId,
          amount: parseFloat(amount),
          category,
          reference_number: receipt_number
        }
      });

    } catch (error) {
      logger.error('Record expense error:', error);
      res.status(500).json({
        error: 'Failed to record expense',
        code: 'EXPENSE_RECORD_ERROR'
      });
    }
  }

  // ثبت درآمد
  async recordRevenue(req, res) {
    try {
      const tenantDB = req.tenant.db;
      const {
        amount,
        currency = 'IRR',
        category,
        description,
        payment_method = 'cash',
        receipt_number,
        customer_name = '',
        notes = ''
      } = req.body;

      const revenue = {
        type: 'revenue',
        amount: parseFloat(amount),
        currency,
        category,
        description,
        payment_method,
        receipt_number,
        customer_name,
        notes,
        created_by: req.user.userId,
        created_by_name: req.user.name,
        created_at: new Date(),
        jalaali_date: moment().format('jYYYY/jMM/jDD'),
        status: 'completed',
        metadata: {
          ip_address: req.ip,
          user_agent: req.get('User-Agent')
        }
      };

      const result = await tenantDB.collection('accounting_entries').insertOne(revenue);

      // به‌روزرسانی صندوق
      await tenantDB.collection('cash_box').updateOne(
        { currency },
        {
          $inc: { balance: parseFloat(amount) },
          $set: { updated_at: new Date() },
          $push: {
            transactions: {
              entry_id: result.insertedId,
              amount: parseFloat(amount),
              type: 'revenue',
              description,
              timestamp: new Date()
            }
          }
        },
        { upsert: true }
      );

      logger.info(`Revenue recorded`, {
        tenantId: req.tenant.id,
        revenueId: result.insertedId,
        amount,
        category,
        userId: req.user.userId
      });

      res.status(201).json({
        success: true,
        message: 'Revenue recorded successfully',
        data: {
          revenue_id: result.insertedId,
          amount: parseFloat(amount),
          category,
          reference_number: receipt_number
        }
      });

    } catch (error) {
      logger.error('Record revenue error:', error);
      res.status(500).json({
        error: 'Failed to record revenue',
        code: 'REVENUE_RECORD_ERROR'
      });
    }
  }

  // صدور گزارش اکسل
  async exportToExcel(req, res) {
    try {
      const {
        report_type,
        start_date,
        end_date,
        currency = 'IRR'
      } = req.query;

      const workbook = new ExcelJS.Workbook();
      workbook.creator = req.tenant.name;
      workbook.created = new Date();

      // Add company info
      workbook.company = req.tenant.name;
      workbook.description = `${report_type} report generated on ${formatJalaliDate(new Date())}`;

      if (report_type === 'profit_loss') {
        await this.generateProfitLossExcel(workbook, req);
      } else if (report_type === 'transactions') {
        await this.generateTransactionsExcel(workbook, req);
      } else if (report_type === 'cash_flow') {
        await this.generateCashFlowExcel(workbook, req);
      } else if (report_type === 'customers') {
        await this.generateCustomersExcel(workbook, req);
      }

      const filename = `${report_type}_${req.tenant.name}_${moment().format('jYYYY-jMM-jDD')}.xlsx`;

      res.setHeader(
        'Content-Type',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${filename}"`
      );

      await workbook.xlsx.write(res);

    } catch (error) {
      logger.error('Export to Excel error:', error);
      res.status(500).json({
        error: 'Failed to export report',
        code: 'EXPORT_ERROR'
      });
    }
  }

  // صدور گزارش PDF
  async exportToPDF(req, res) {
    try {
      const {
        report_type,
        start_date,
        end_date
      } = req.query;

      const doc = new PDFDocument({ margin: 50 });
      const filename = `${report_type}_${moment().format('jYYYY-jMM-jDD')}.pdf`;

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

      doc.pipe(res);

      // PDF Header
      doc.fontSize(16).text(req.tenant.name, 50, 50);
      doc.fontSize(12).text(`گزارش ${report_type}`, 50, 80);
      doc.text(`تاریخ: ${formatJalaliDate(new Date())}`, 50, 100);
      
      if (start_date && end_date) {
        doc.text(`دوره: ${formatJalaliDate(start_date)} تا ${formatJalaliDate(end_date)}`, 50, 120);
      }

      // Generate content based on report type
      if (report_type === 'profit_loss') {
        await this.generateProfitLossPDF(doc, req);
      } else if (report_type === 'cash_flow') {
        await this.generateCashFlowPDF(doc, req);
      }

      doc.end();

    } catch (error) {
      logger.error('Export to PDF error:', error);
      res.status(500).json({
        error: 'Failed to export PDF',
        code: 'PDF_EXPORT_ERROR'
      });
    }
  }

  // Helper Methods
  getGroupingExpression(groupBy) {
    switch (groupBy) {
      case 'daily':
        return { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } };
      case 'weekly':
        return { $dateToString: { format: '%Y-W%U', date: '$created_at' } };
      case 'monthly':
        return { $dateToString: { format: '%Y-%m', date: '$created_at' } };
      case 'yearly':
        return { $dateToString: { format: '%Y', date: '$created_at' } };
      default:
        return { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } };
    }
  }

  calculateProfitLossSummary(commissionRevenue, expenses, otherRevenue) {
    const totalCommission = commissionRevenue.reduce((sum, item) => sum + item.total_commission, 0);
    const totalOtherRevenue = otherRevenue.reduce((sum, item) => sum + item.total_amount, 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + item.total_amount, 0);
    
    const grossRevenue = totalCommission + totalOtherRevenue;
    const netProfit = grossRevenue - totalExpenses;
    const profitMargin = grossRevenue > 0 ? (netProfit / grossRevenue * 100) : 0;

    return {
      gross_revenue: grossRevenue,
      commission_revenue: totalCommission,
      other_revenue: totalOtherRevenue,
      total_expenses: totalExpenses,
      net_profit: netProfit,
      profit_margin: Math.round(profitMargin * 100) / 100,
      expense_ratio: grossRevenue > 0 ? (totalExpenses / grossRevenue * 100) : 0
    };
  }

  calculateTrends(commissionRevenue, expenses, groupBy) {
    // Calculate period-over-period trends
    const revenueByPeriod = commissionRevenue.reduce((acc, item) => {
      const period = item._id.date;
      acc[period] = (acc[period] || 0) + item.total_commission;
      return acc;
    }, {});

    const expensesByPeriod = expenses.reduce((acc, item) => {
      const period = item._id.date;
      acc[period] = (acc[period] || 0) + item.total_amount;
      return acc;
    }, {});

    const periods = [...new Set([...Object.keys(revenueByPeriod), ...Object.keys(expensesByPeriod)])].sort();
    
    const trends = periods.map((period, index) => {
      const revenue = revenueByPeriod[period] || 0;
      const expense = expensesByPeriod[period] || 0;
      const profit = revenue - expense;

      let revenueGrowth = 0;
      let expenseGrowth = 0;
      let profitGrowth = 0;

      if (index > 0) {
        const prevPeriod = periods[index - 1];
        const prevRevenue = revenueByPeriod[prevPeriod] || 0;
        const prevExpense = expensesByPeriod[prevPeriod] || 0;
        const prevProfit = prevRevenue - prevExpense;

        revenueGrowth = prevRevenue > 0 ? ((revenue - prevRevenue) / prevRevenue * 100) : 0;
        expenseGrowth = prevExpense > 0 ? ((expense - prevExpense) / prevExpense * 100) : 0;
        profitGrowth = prevProfit !== 0 ? ((profit - prevProfit) / Math.abs(prevProfit) * 100) : 0;
      }

      return {
        period,
        revenue,
        expense,
        profit,
        revenue_growth: Math.round(revenueGrowth * 100) / 100,
        expense_growth: Math.round(expenseGrowth * 100) / 100,
        profit_growth: Math.round(profitGrowth * 100) / 100
      };
    });

    return trends;
  }

  calculateNetCashFlow(transactionFlow, otherFlow) {
    const transactionNet = transactionFlow.reduce((total, item) => {
      return total + (item.cash_in - item.cash_out);
    }, 0);

    const otherNet = otherFlow.reduce((total, item) => {
      return total + (item.cash_in - item.cash_out);
    }, 0);

    return transactionNet + otherNet;
  }

  sumCashFlow(transactionFlow, otherFlow, direction) {
    const field = direction === 'in' ? 'cash_in' : 'cash_out';
    
    const transactionSum = transactionFlow.reduce((total, item) => total + item[field], 0);
    const otherSum = otherFlow.reduce((total, item) => total + item[field], 0);
    
    return transactionSum + otherSum;
  }

  async calculateAssets(tenantDB, date) {
    // نقد و معادل نقد
    const cashBalances = await tenantDB.collection('cash_box').find({}).toArray();
    const totalCash = cashBalances.reduce((sum, balance) => sum + balance.balance, 0);

    // مطالبات مشتریان
    const customerReceivables = await tenantDB.collection('customers').aggregate([
      {
        $match: {
          current_balance: { $lt: 0 }, // منفی = مطالبه
          created_at: { $lte: date }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: { $abs: '$current_balance' } }
        }
      }
    ]).toArray();

    return {
      cash_and_equivalents: totalCash,
      accounts_receivable: customerReceivables[0]?.total || 0,
      total: totalCash + (customerReceivables[0]?.total || 0)
    };
  }

  async calculateLiabilities(tenantDB, date) {
    // بدهی به مشتریان
    const customerLiabilities = await tenantDB.collection('customers').aggregate([
      {
        $match: {
          current_balance: { $gt: 0 }, // مثبت = بدهی
          created_at: { $lte: date }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$current_balance' }
        }
      }
    ]).toArray();

    return {
      accounts_payable: customerLiabilities[0]?.total || 0,
      total: customerLiabilities[0]?.total || 0
    };
  }

  async calculateEquity(tenantDB, date) {
    // سرمایه اولیه + سود انباشته
    const initialCapital = 10000000; // باید از تنظیمات خوانده شود

    const retainedEarnings = await tenantDB.collection('transactions').aggregate([
      {
        $match: {
          status: 'completed',
          created_at: { $lte: date }
        }
      },
      {
        $group: {
          _id: null,
          total_commission: { $sum: '$commission' }
        }
      }
    ]).toArray();

    const totalExpenses = await tenantDB.collection('accounting_entries').aggregate([
      {
        $match: {
          type: 'expense',
          created_at: { $lte: date }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$amount' }
        }
      }
    ]).toArray();

    const netIncome = (retainedEarnings[0]?.total_commission || 0) - (totalExpenses[0]?.total || 0);

    return {
      initial_capital: initialCapital,
      retained_earnings: netIncome,
      total: initialCapital + netIncome
    };
  }

  calculateDailyPerformance(transactions, expenses) {
    const totalTransactions = transactions.reduce((sum, t) => sum + t.count, 0);
    const totalCommission = transactions.reduce((sum, t) => sum + t.total_commission, 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.total, 0);

    const avgCommissionPerTransaction = totalTransactions > 0 ? totalCommission / totalTransactions : 0;
    const profitMargin = totalCommission > 0 ? ((totalCommission - totalExpenses) / totalCommission * 100) : 0;

    return {
      transactions_per_day: totalTransactions,
      avg_commission_per_transaction: Math.round(avgCommissionPerTransaction * 100) / 100,
      profit_margin: Math.round(profitMargin * 100) / 100,
      cost_efficiency: totalCommission > 0 ? (totalExpenses / totalCommission * 100) : 0
    };
  }

  async generateCashFlowForecast(tenantDB, dateFilter) {
    // ساده‌ترین پیش‌بینی بر اساس میانگین دوره‌های قبل
    const historicalData = await tenantDB.collection('transactions').aggregate([
      { $match: { ...dateFilter, status: 'completed' } },
      {
        $group: {
          _id: { $dayOfWeek: '$created_at' },
          avg_commission: { $avg: '$commission' },
          avg_volume: { $avg: '$amount_from' },
          count: { $sum: 1 }
        }
      }
    ]).toArray();

    // پیش‌بینی 7 روز آینده
    const forecast = [];
    for (let i = 1; i <= 7; i++) {
      const futureDate = moment().add(i, 'days');
      const dayOfWeek = futureDate.day() + 1; // MongoDB uses 1-7 for Sun-Sat
      
      const historicalDay = historicalData.find(h => h._id === dayOfWeek);
      
      forecast.push({
        date: futureDate.format('YYYY-MM-DD'),
        jalaali_date: futureDate.format('jYYYY/jMM/jDD'),
        predicted_transactions: historicalDay?.count || 0,
        predicted_commission: historicalDay?.avg_commission || 0,
        predicted_volume: historicalDay?.avg_volume || 0,
        confidence: historicalDay ? 'medium' : 'low'
      });
    }

    return forecast;
  }

  async generateProfitLossExcel(workbook, req) {
    const worksheet = workbook.addWorksheet('Profit & Loss');
    
    // Styling
    worksheet.getRow(1).font = { bold: true, size: 14 };
    worksheet.getRow(2).font = { bold: true };

    // Headers
    worksheet.columns = [
      { header: 'شرح', key: 'description', width: 25 },
      { header: 'مبلغ (ریال)', key: 'amount', width: 20 },
      { header: 'درصد', key: 'percentage', width: 15 },
      { header: 'نوع', key: 'type', width: 15 }
    ];

    // Add title
    worksheet.mergeCells('A1:D1');
    worksheet.getCell('A1').value = `گزارش سود و زیان - ${req.tenant.name}`;
    worksheet.getCell('A1').alignment = { horizontal: 'center' };

    // Sample data (replace with actual data)
    const data = [
      { description: 'درآمد کارمزد', amount: 5000000, percentage: 100, type: 'درآمد' },
      { description: 'هزینه‌های عملیاتی', amount: 1000000, percentage: 20, type: 'هزینه' },
      { description: 'سود خالص', amount: 4000000, percentage: 80, type: 'سود' }
    ];

    data.forEach(row => {
      worksheet.addRow(row);
    });

    // Format numbers
    worksheet.getColumn('B').numFmt = '#,##0';
    worksheet.getColumn('C').numFmt = '0.00%';
  }

  async generateCashFlowExcel(workbook, req) {
    const worksheet = workbook.addWorksheet('Cash Flow');
    
    worksheet.columns = [
      { header: 'تاریخ', key: 'date', width: 15 },
      { header: 'ورودی نقد', key: 'cash_in', width: 20 },
      { header: 'خروجی نقد', key: 'cash_out', width: 20 },
      { header: 'خالص جریان نقدی', key: 'net_flow', width: 20 }
    ];

    // Sample data
    const cashFlowData = [
      {
        date: moment().format('jYYYY/jMM/jDD'),
        cash_in: 10000000,
        cash_out: 2000000,
        net_flow: 8000000
      }
    ];

    cashFlowData.forEach(row => {
      worksheet.addRow(row);
    });

    worksheet.getColumn('B').numFmt = '#,##0';
    worksheet.getColumn('C').numFmt = '#,##0';
    worksheet.getColumn('D').numFmt = '#,##0';
  }

  async generateProfitLossPDF(doc, req) {
    doc.moveDown(2);
    doc.fontSize(14).text('گزارش سود و زیان', { align: 'center' });
    doc.moveDown();

    // Sample profit/loss data
    const profitLossData = [
      ['درآمد کارمزد', '5,000,000 ریال'],
      ['هزینه‌های عملیاتی', '1,000,000 ریال'],
      ['سود خالص', '4,000,000 ریال']
    ];

    let y = doc.y;
    profitLossData.forEach(([label, value]) => {
      doc.text(label, 50, y);
      doc.text(value, 300, y);
      y += 20;
    });
  }

  async generateCashFlowPDF(doc, req) {
    doc.moveDown(2);
    doc.fontSize(14).text('گزارش جریان نقدی', { align: 'center' });
    doc.moveDown();

    // Sample cash flow data
    doc.text('ورودی نقد: 10,000,000 ریال');
    doc.text('خروجی نقد: 2,000,000 ریال');
    doc.text('خالص جریان نقدی: 8,000,000 ریال');
  }
}

module.exports = new AccountingController();