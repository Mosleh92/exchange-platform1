const express = require('express');
const { body, query, param } = require('express-validator');
const TransactionController = require('../controllers/transaction.controller');
const tenantIsolation = require('../middleware/tenantIsolation');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply middleware to all routes
router.use(auth);
router.use(tenantIsolation);

// Validation rules
const createTransactionValidation = [
  body('customer_id').isMongoId().withMessage('Invalid customer ID'),
  body('currency_from').isIn(['USD', 'EUR', 'GBP', 'AED', 'IRR']).withMessage('Invalid source currency'),
  body('currency_to').optional().isIn(['USD', 'EUR', 'GBP', 'AED', 'IRR']).withMessage('Invalid target currency'),
  body('amount_from').isFloat({ min: 0.01 }).withMessage('Amount must be greater than 0'),
  body('payment_method').optional().isIn(['cash', 'transfer', 'card', 'cheque']).withMessage('Invalid payment method'),
  body('custom_rate').optional().isFloat({ min: 0 }).withMessage('Invalid exchange rate'),
  body('receipt_number').optional().isString().isLength({ max: 50 }).withMessage('Receipt number too long'),
  body('notes').optional().isString().isLength({ max: 500 }).withMessage('Notes too long')
];

const getTransactionsValidation = [
  query('page').optional().isInt({ min: 1 }).withMessage('Invalid page number'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Invalid limit'),
  query('type').optional().isIn(['buy', 'sell']).withMessage('Invalid transaction type'),
  query('status').optional().isIn(['pending', 'completed', 'cancelled']).withMessage('Invalid status'),
  query('start_date').optional().isISO8601().withMessage('Invalid start date'),
  query('end_date').optional().isISO8601().withMessage('Invalid end date')
];

// Routes
router.post('/buy', createTransactionValidation, TransactionController.createBuyTransaction);
router.post('/sell', createTransactionValidation, TransactionController.createSellTransaction);

router.get('/', getTransactionsValidation, TransactionController.getTransactions);
router.get('/:id', param('id').isMongoId(), TransactionController.getTransactionById);

router.delete('/:id', param('id').isMongoId(), TransactionController.deleteTransaction);

module.exports = router;