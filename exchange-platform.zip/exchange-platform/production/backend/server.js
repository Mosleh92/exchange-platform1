const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();

// Security & Performance
app.use(helmet());
app.use(compression());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { error: 'Too many requests from this IP' }
});
app.use('/api/', limiter);

// CORS for production
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? [
        'https://your-frontend.netlify.app',
        'https://exchange-saas.netlify.app'
      ]
    : ['http://localhost:3000', 'http://localhost:8080'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy',
    environment: process.env.NODE_ENV || 'development',
    timestamp: new Date().toISOString(),
    version: '2.0.0'
  });
});

// Multi-tenant middleware
const tenantMiddleware = (req, res, next) => {
  const tenantId = req.headers['x-tenant-id'] || req.query.tenant;
  
  if (!tenantId) {
    return res.status(400).json({
      error: 'Tenant ID required',
      code: 'MISSING_TENANT'
    });
  }

  // Add tenant context
  req.tenant = { id: tenantId };
  next();
};

// Authentication routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password, tenant_id } = req.body;

    // Validation
    if (!email || !password || !tenant_id) {
      return res.status(400).json({
        error: 'Email, password, and tenant ID are required',
        code: 'MISSING_CREDENTIALS'
      });
    }

    // TODO: Real authentication logic
    // For now, mock response
    const mockUser = {
      id: '12345',
      email,
      name: 'Test User',
      role: 'admin',
      tenant_id
    };

    const token = 'mock-jwt-token'; // TODO: Generate real JWT

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: mockUser
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      error: 'Authentication failed',
      code: 'AUTH_ERROR'
    });
  }
});

// Protected routes with tenant isolation
app.use('/api/tenants', tenantMiddleware);
app.use('/api/transactions', tenantMiddleware);
app.use('/api/customers', tenantMiddleware);

// Transactions API
app.get('/api/transactions', (req, res) => {
  const { tenant } = req;
  
  // Mock transaction data for demo
  const mockTransactions = [
    {
      id: '1',
      type: 'buy',
      amount: 1000,
      currency_from: 'USD',
      currency_to: 'IRR',
      exchange_rate: 42000,
      commission: 15,
      created_at: new Date(),
      customer_name: 'احمد محمدی'
    },
    {
      id: '2', 
      type: 'sell',
      amount: 500,
      currency_from: 'EUR',
      currency_to: 'IRR',
      exchange_rate: 45000,
      commission: 12,
      created_at: new Date(),
      customer_name: 'فاطمه احمدی'
    }
  ];

  res.json({
    success: true,
    data: mockTransactions,
    tenant_id: tenant.id
  });
});

app.post('/api/transactions', (req, res) => {
  const { tenant } = req;
  const {
    type,
    amount,
    currency_from,
    currency_to,
    customer_name,
    exchange_rate
  } = req.body;

  // Calculate commission (1.5% for demo)
  const commission = amount * 0.015;
  const net_amount = type === 'buy' ? amount + commission : amount - commission;

  const transaction = {
    id: Date.now().toString(),
    type,
    amount,
    currency_from,
    currency_to,
    customer_name,
    exchange_rate,
    commission,
    net_amount,
    status: 'completed',
    created_at: new Date(),
    tenant_id: tenant.id
  };

  res.status(201).json({
    success: true,
    message: 'Transaction created successfully',
    data: transaction
  });
});

// Customers API
app.get('/api/customers', (req, res) => {
  const { tenant } = req;

  const mockCustomers = [
    {
      id: '1',
      name: 'احمد محمدی',
      phone: '+98 912 345 6789',
      email: 'ahmad@example.com',
      balance: 2500,
      total_transactions: 15
    },
    {
      id: '2',
      name: 'فاطمه احمدی', 
      phone: '+98 912 987 6543',
      email: 'fateme@example.com',
      balance: 1200,
      total_transactions: 8
    }
  ];

  res.json({
    success: true,
    data: mockCustomers,
    tenant_id: tenant.id
  });
});

app.post('/api/customers', (req, res) => {
  const { tenant } = req;
  const { name, phone, email, initial_balance = 0 } = req.body;

  const customer = {
    id: Date.now().toString(),
    name,
    phone,
    email,
    balance: initial_balance,
    total_transactions: 0,
    created_at: new Date(),
    tenant_id: tenant.id
  };

  res.status(201).json({
    success: true,
    message: 'Customer created successfully', 
    data: customer
  });
});

// Reports API
app.get('/api/reports/daily', (req, res) => {
  const { tenant } = req;
  const { date = new Date().toISOString().split('T')[0] } = req.query;

  const mockReport = {
    date,
    tenant_id: tenant.id,
    transactions: {
      total: 25,
      buy: 15,
      sell: 10
    },
    revenue: {
      total_commission: 450.75,
      total_volume: 50000
    },
    profit: {
      gross: 450.75,
      expenses: 50.00,
      net: 400.75
    }
  };

  res.json({
    success: true,
    data: mockReport
  });
});

// Exchange rates API
app.get('/api/rates', (req, res) => {
  const mockRates = {
    USD_IRR: { buy: 42000, sell: 42500 },
    EUR_IRR: { buy: 45000, sell: 45600 },
    GBP_IRR: { buy: 52000, sell: 52700 },
    AED_IRR: { buy: 11450, sell: 11580 },
    updated_at: new Date()
  };

  res.json({
    success: true,
    data: mockRates
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.path
  });
});

// MongoDB connection (when ready)
if (process.env.MONGODB_URI) {
  mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('✅ Connected to MongoDB'))
    .catch(err => console.error('❌ MongoDB connection error:', err));
}

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Exchange SaaS Backend running on port ${PORT}`);
  console.log(`🔗 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;